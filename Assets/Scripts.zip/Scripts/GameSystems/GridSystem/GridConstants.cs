public static class GridConstants
{
    public static readonly int Rows = 10;
    public static readonly int Columns = 10;
    public static readonly float CellSize = 1.1f;
}
