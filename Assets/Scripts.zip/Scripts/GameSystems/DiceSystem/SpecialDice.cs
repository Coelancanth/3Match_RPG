using UnityEngine;

public class SpecialDice
{
    
}
