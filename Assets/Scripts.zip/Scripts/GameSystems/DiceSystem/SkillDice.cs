using UnityEngine;

public class SkillDice
{
    
}
